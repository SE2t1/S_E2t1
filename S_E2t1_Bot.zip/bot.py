import time

def start_bot():
    print("Bot started...")
    while True:
        # منطق التداول التجريبي هنا
        print("Scanning for trades...")
        time.sleep(10)

if __name__ == "__main__":
    start_bot()